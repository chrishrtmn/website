chrishrtmn.com paparazzi kit

Logos/
  ope-offwhite.svg/.png   OPE! wordmark, off-white, for dark backgrounds
  ope-volt.svg/.png       OPE! wordmark, Volt, for dark backgrounds
  ope-ink.svg/.png        OPE! wordmark, ink, for light backgrounds
  ope-tile.svg/.png       OPE! on a dark rounded tile; avatars and app icons
  ch-offwhite.svg/.png    CH monogram, off-white
  ch-volt.svg/.png        CH monogram, Volt
  ch-tile.svg/.png        CH monogram on a dark tile
Headshots/
  chris-hartman.jpg       500 px, web use
colours.txt               hex and rgb values, font names and licences
boilerplate.txt           long and short bios, name, handle, location

Please don't recolour, outline, stretch, or add effects to the marks. Volt is the only accent.
