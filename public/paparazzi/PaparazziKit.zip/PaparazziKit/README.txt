chrishrtmn.com paparazzi kit

Logos/
  ope-offwhite.svg/.png   OPE! wordmark, off-white, for dark backgrounds
  ope-caution.svg/.png    OPE! wordmark, Caution, for dark backgrounds
  ope-plate-caution.svg/.png OPE! wordmark, ink on a Caution plate (inverted)
  ope-plate-night.svg/.png OPE! wordmark, Caution on a Night plate
  ope-tile.svg/.png       OPE! on a dark rounded tile; avatars and app icons
  ope-tile-caution.svg/.png OPE! on a Caution rounded tile (inverted)
Headshots/
  chris-hartman.jpg       500 px, web use
colours.txt               hex and rgb values, font names and licences
boilerplate.txt           long and short bios, name, handle, location

Please don't recolour, outline, stretch, or add effects to the marks. Caution is the only accent.
