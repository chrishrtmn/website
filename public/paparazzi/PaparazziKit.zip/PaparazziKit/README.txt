chrishrtmn.com paparazzi kit

Logos/
  ope-offwhite.svg/.png   OPE! wordmark, off-white, for dark backgrounds
  ope-volt.svg/.png       OPE! wordmark, Volt, for dark backgrounds
  ope-ink.svg/.png        OPE! wordmark, ink, for light backgrounds
  ope-plate-volt.svg/.png OPE! wordmark, ink on a Volt plate (inverted)
  ope-plate-night.svg/.png OPE! wordmark, Volt on a Night plate
  ope-tile.svg/.png       OPE! on a dark rounded tile; avatars and app icons
  ope-tile-volt.svg/.png  OPE! on a Volt rounded tile (inverted)
Headshots/
  chris-hartman.jpg       500 px, web use
colours.txt               hex and rgb values, font names and licences
boilerplate.txt           long and short bios, name, handle, location

Please don't recolour, outline, stretch, or add effects to the marks. Volt is the only accent.
